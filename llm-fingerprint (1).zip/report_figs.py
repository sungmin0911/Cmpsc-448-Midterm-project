"""Turns results/*.json into figures (results/figs/*.png) and results/tables.md
for the report. Run after train.py:  python report_figs.py
"""
import json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

R, F = "results", "results/figs"
os.makedirs(F, exist_ok=True)
load = lambda n: json.load(open(f"{R}/{n}.json")) if os.path.exists(f"{R}/{n}.json") else None
NAMES = {"cnn": "CNN", "lstm": "BiLSTM", "tfidf": "TF-IDF + LogReg"}
md = []

def bars(ax, groups, series, values, errs, ylabel, chance=None):
    x = np.arange(len(groups)); w = 0.8 / len(series)
    for i, s in enumerate(series):
        ax.bar(x + (i - (len(series) - 1) / 2) * w, values[i], w, yerr=errs[i], capsize=3, label=s)
    ax.set_xticks(x); ax.set_xticklabels(groups); ax.set_ylabel(ylabel); ax.set_ylim(0, 1.25); ax.set_yticks(np.arange(0, 1.01, 0.2))
    if chance is not None:
        ax.axhline(chance, ls="--", c="gray", lw=1); ax.text(len(groups) - 0.5, chance + 0.02, "chance", color="gray", ha="right")
    ax.legend(frameon=False, loc="upper left", ncol=len(series), fontsize=8); ax.spines[["top", "right"]].set_visible(False)

def cm_plot(cm, labels, title, path):
    cm = np.array(cm, dtype=float); cmn = cm / cm.sum(1, keepdims=True)
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, f"{cmn[i, j]:.2f}", ha="center", va="center", color="white" if cmn[i, j] > 0.5 else "black", fontsize=9)
    ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels, rotation=30)
    ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(title, fontsize=10)
    fig.tight_layout(); fig.savefig(path, dpi=200); plt.close(fig)

r12 = load("rq1_rq2")
if r12:
    labels, res, chance = r12["labels"], r12["results"], r12["chance"]
    md += ["## RQ1/RQ2: accuracy and macro-F1 (mean ± std over seeds, test = unseen prompts)\n",
           f"Chance = {chance:.3f}\n", "| Input | Model | Accuracy | Macro-F1 |", "|---|---|---|---|"]
    for mode, rr in res.items():
        for a, m in rr.items():
            md.append(f"| {mode} | {NAMES[a]} | {m['acc']:.3f} ± {m['acc_std']:.3f} | {m['macro_f1']:.3f} ± {m['macro_f1_std']:.3f} |")
    for a in [x for x in ("cnn", "lstm") if x in res["output"]]:
        cm_plot(res["output"][a]["cm"], labels, f"RQ1 {NAMES[a]} (output only)", f"{F}/rq1_cm_{a}.png")
    modes = list(res); archs = list(res[modes[0]])
    fig, ax = plt.subplots(figsize=(6, 3.5))
    bars(ax, modes, [NAMES[a] for a in archs], [[res[m][a]["acc"] for m in modes] for a in archs],
         [[res[m][a]["acc_std"] for m in modes] for a in archs], "Test accuracy", chance)
    ax.set_title("RQ2: what the classifier sees"); fig.tight_layout(); fig.savefig(f"{F}/rq2_modes.png", dpi=200); plt.close(fig)
    # training curves (seed 0, output only)
    nn = [x for x in ("cnn", "lstm") if x in res["output"]]
    if nn:
        fig, axs = plt.subplots(1, 2, figsize=(8, 3))
        for a in nn:
            h = res["output"][a].get("history_seed0", [])
            axs[0].plot([e["epoch"] for e in h], [e["train_loss"] for e in h], marker="o", label=NAMES[a])
            axs[1].plot([e["epoch"] for e in h], [e["val_macro_f1"] for e in h], marker="o", label=NAMES[a])
        axs[0].set_title("Train loss"); axs[1].set_title("Validation macro-F1")
        for ax in axs: ax.set_xlabel("Epoch"); ax.legend(frameon=False); ax.spines[["top", "right"]].set_visible(False)
        fig.tight_layout(); fig.savefig(f"{F}/training_curves.png", dpi=200); plt.close(fig)
    first = next(iter(res["output"].values()))["per_task_acc"]
    md += ["\n### Per-task test accuracy (output only)\n", "| Model | " + " | ".join(first) + " |",
           "|---|" + "---|" * len(first)]
    for a, m in res["output"].items():
        md.append(f"| {NAMES[a]} | " + " | ".join(f"{v:.3f}" for v in m["per_task_acc"].values()) + " |")

r3 = load("rq3")
if r3:
    groups = list(r3["results"]); archs = [a for a in ("cnn", "lstm", "tfidf") if a in r3["results"][groups[0]]]
    any_ = r3["results"][groups[0]][archs[0]]
    md += ["\n## RQ3: does the classifier work on a task type it never saw?\n",
           f"Same training size ({any_['n_train_prompts']} prompts) in both conditions; both tested on the same held-out prompts of the task.\n",
           "| Held-out task | Model | Seen task | Unseen task | Drop |", "|---|---|---|---|---|"]
    fig, axs = plt.subplots(1, len(archs), figsize=(4 * len(archs), 3.3), sharey=True, squeeze=False)
    for ax, a in zip(axs[0], archs):
        seen = [r3["results"][g][a]["seen"]["acc"] for g in groups]
        unseen = [r3["results"][g][a]["unseen"]["acc"] for g in groups]
        for g, s_, u in zip(groups, seen, unseen):
            sd = r3["results"][g][a]
            md.append(f"| {g} (n={sd['n_test_prompts']}) | {NAMES[a]} | {s_:.3f} ± {sd['seen']['acc_std']:.3f} | {u:.3f} ± {sd['unseen']['acc_std']:.3f} | {s_ - u:+.3f} |")
        bars(ax, groups, ["seen task", "unseen task"], [seen, unseen],
             [[r3["results"][g][a]["seen"]["acc_std"] for g in groups], [r3["results"][g][a]["unseen"]["acc_std"] for g in groups]],
             "Accuracy", r3["chance"])
        ax.set_title(NAMES[a])
    fig.tight_layout(); fig.savefig(f"{F}/rq3_cross_task.png", dpi=200); plt.close(fig)
    # RQ3 (ii): which models stay identifiable on the unseen task? per-model recall
    lab = r3["labels"]; nn_archs = [a for a in ("cnn", "lstm") if a in archs] or archs
    md += ["\n### RQ3 per-model recall, seen → unseen (" + " / ".join(NAMES[a] for a in nn_archs) + ")\n",
           "| Held-out task | " + " | ".join(lab) + " |", "|---|" + "---|" * len(lab)]
    rec = lambda cm: np.diag(np.array(cm)) / np.maximum(1, np.array(cm).sum(1))
    for g in groups:
        cells = []
        for i in range(len(lab)):
            cells.append(" / ".join(f"{rec(r3['results'][g][a]['seen']['cm'])[i]:.2f}→{rec(r3['results'][g][a]['unseen']['cm'])[i]:.2f}" for a in nn_archs))
        md.append(f"| {g} | " + " | ".join(cells) + " |")
    for g in groups:
        for a in nn_archs[:1]:
            cm_plot(r3["results"][g][a]["unseen"]["cm"], lab, f"RQ3 {NAMES[a]}, unseen task = {g}", f"{F}/rq3_cm_{a}_{g}.png")

r4 = load("rq4")
if r4:
    abl = r4["ablations"]; names = list(abl)
    md += ["\n## RQ4: signal-removal ablations (output only)\n", "| Variant | CNN acc | BiLSTM acc |", "|---|---|---|"]
    for n in names:
        md.append(f"| {n} | {abl[n]['cnn']['acc']:.3f} ± {abl[n]['cnn']['acc_std']:.3f} | {abl[n]['lstm']['acc']:.3f} ± {abl[n]['lstm']['acc_std']:.3f} |")
    if "top_ngrams" in r4:
        md += ["\n### Most indicative n-grams per model (TF-IDF + LogReg weights)\n"]
        for c, ws in r4["top_ngrams"].items(): md.append(f"- **{c}**: " + ", ".join(f"`{w}`" for w in ws))
    md.append(f"\nStyle-features-only logistic regression: acc = {r4['feature_only']['acc']:.3f} ± {r4['feature_only']['acc_std']:.3f}")
    fig, ax = plt.subplots(figsize=(7, 3.5))
    bars(ax, names, ["CNN", "BiLSTM"], [[abl[n][a]["acc"] for n in names] for a in ("cnn", "lstm")],
         [[abl[n][a]["acc_std"] for n in names] for a in ("cnn", "lstm")], "Test accuracy", 1 / len(r4["labels"]))
    ax.set_title("RQ4: accuracy after removing signals"); fig.tight_layout(); fig.savefig(f"{F}/rq4_ablations.png", dpi=200); plt.close(fig)
    # style stats: a few key features per model
    st = r4["style_stats"]; models = list(next(iter(st.values())))
    keys = [k for k in ("n_words", "ttr_first200", "headers", "bullets", "bold", "latex", "emoji") if k in st]
    fig, axs = plt.subplots(1, len(keys), figsize=(2.2 * len(keys), 2.8))
    for ax, k in zip(axs, keys):
        ax.bar(models, [st[k][m] for m in models], color=[f"C{i}" for i in range(len(models))])
        ax.set_title(k, fontsize=9); ax.tick_params(axis="x", rotation=45, labelsize=8); ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout(); fig.savefig(f"{F}/rq4_style_stats.png", dpi=200); plt.close(fig)
    md += ["\n### Mean style statistics per model\n", "| Feature | " + " | ".join(models) + " |", "|---|" + "---|" * len(models)]
    for k, v in st.items():
        md.append(f"| {k} | " + " | ".join(f"{v[m]:.2f}" for m in models) + " |")

open(f"{R}/tables.md", "w").write("\n".join(md) + "\n")
print("wrote", f"{R}/tables.md", "and figures in", F, ":", sorted(os.listdir(F)))
