"""CNN and BiLSTM classifiers for identifying which LLM wrote a response.

Experiments (each writes results/<name>.json and prints a summary table):
  RQ1  output-only classification (CNN, BiLSTM, + TF-IDF/LogReg baseline)
  RQ2  input-only vs output-only vs input+output
  RQ3  held-out task group: same-size training with vs without that task, same test set
  RQ4  style statistics, feature-only classifier, and signal-removal ablations

Run (Colab, GPU runtime):
  python train.py --rq 1 2 3 4          # everything (~10-20 min on a T4)
  python train.py --rq 1 --seeds 1      # quick check

Design choices worth explaining in the report:
  * Split is BY PROMPT: a prompt and all of its responses land in exactly one of
    train/val/test, so the test set has only unseen prompts.
  * Every prompt was answered by every model, so classes are perfectly balanced
    and the input alone carries no label information (chance = 1/num_models).
  * Tokenizer keeps case, punctuation, and newlines as tokens, because
    formatting (markdown, bullets, line breaks) is plausibly part of the fingerprint.
  * Each run is repeated over several seeds; we report mean +/- std.
"""
import argparse, json, os, random, re, time
from collections import Counter

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
PAD, UNK, SEP = 0, 1, 2
MAX_IN, MAX_OUT = 64, 600

# ----------------------------------------------------------------------------- data

def load_data(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8")]
    df = pd.DataFrame(rows)
    df["output"] = df["output"].fillna("").astype(str)
    df = df[df["output"].str.strip() != ""]                     # empty responses are unusable
    df = df.drop_duplicates(["llm", "prompt_id"])
    # keep only prompts answered by every model -> perfectly balanced classes
    n_models = df["llm"].nunique()
    full = df.groupby("prompt_id")["llm"].nunique()
    df = df[df["prompt_id"].isin(full[full == n_models].index)].reset_index(drop=True)
    return df

def split_by_prompt(df, seed, test=0.15, val=0.15):
    p = df.drop_duplicates("prompt_id")[["prompt_id", "task"]]
    tr, te = train_test_split(p, test_size=test, stratify=p["task"], random_state=seed)
    tr, va = train_test_split(tr, test_size=val / (1 - test), stratify=tr["task"], random_state=seed)
    pick = lambda s: df[df["prompt_id"].isin(s["prompt_id"])].reset_index(drop=True)
    return pick(tr), pick(va), pick(te)

def split_train_val(df, seed, val=0.15):
    p = df.drop_duplicates("prompt_id")[["prompt_id", "task"]]
    tr, va = train_test_split(p, test_size=val, stratify=p["task"], random_state=seed)
    pick = lambda s: df[df["prompt_id"].isin(s["prompt_id"])].reset_index(drop=True)
    return pick(tr), pick(va)

TOKEN_RE = re.compile(r"\n|\w+|[^\w\s]")

def tokenize(text):
    return TOKEN_RE.findall(text)

# Signal-removal transforms used by the RQ4 ablations
def strip_formatting(t):
    t = re.sub(r"```.*?\n", "", t)                 # code fence lines' language tags
    t = re.sub(r"[#*_`>|~]", " ", t)                # markdown symbols
    t = re.sub(r"^\s*([-+]|\d+\.)\s+", " ", t, flags=re.M)  # list markers
    return re.sub(r"\s+", " ", t).strip()           # collapse all whitespace/newlines

def lower_no_punct(t):
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", t.lower())).strip()

TRANSFORMS = {"none": lambda t: t, "no_format": strip_formatting, "lower_no_punct": lower_no_punct}

class Vocab:
    def __init__(self, token_lists, min_freq=2, max_size=30000):
        c = Counter(t for toks in token_lists for t in toks)
        self.itos = ["<pad>", "<unk>", "<sep>"] + [t for t, n in c.most_common(max_size)
                                                   if n >= min_freq and t not in ("<pad>", "<unk>", "<sep>")]
        self.stoi = {t: i for i, t in enumerate(self.itos)}
    def encode(self, toks):
        return [self.stoi.get(t, UNK) for t in toks]
    def __len__(self):
        return len(self.itos)

def make_sequences(df, mode, transform, max_out):
    seqs = []
    for inp, out in zip(df["input"], df["output"]):
        ti, to = tokenize(inp)[:MAX_IN], tokenize(TRANSFORMS[transform](out))[:max_out]
        if mode == "input":
            s = ti
        elif mode == "output":
            s = to
        else:  # both
            s = ti + ["<sep>"] + to
        seqs.append(s if s else ["<unk>"])
    return seqs

def to_tensor(seqs, vocab):
    ids = [vocab.encode(s) for s in seqs]
    L = max(len(x) for x in ids)
    X = torch.full((len(ids), L), PAD, dtype=torch.long)
    for i, x in enumerate(ids):
        X[i, :len(x)] = torch.tensor(x)
    return X, torch.tensor([len(x) for x in ids])

# ----------------------------------------------------------------------------- models

class CNN(nn.Module):
    """Kim (2014)-style text CNN: parallel 1D convolutions with widths 3/4/5
    act as learned n-gram detectors; max-over-time pooling keeps each
    filter's strongest match anywhere in the text."""
    def __init__(self, vocab_size, n_classes, emb=128, filters=128, widths=(3, 4, 5), dropout=0.5):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, emb, padding_idx=PAD)
        self.convs = nn.ModuleList([nn.Conv1d(emb, filters, w, padding=w // 2) for w in widths])
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(filters * len(widths), n_classes)
    def forward(self, x, lengths):
        e = self.emb(x).transpose(1, 2)                         # B x E x T
        mask = (x != PAD).unsqueeze(1)                          # B x 1 x T
        pooled = []
        for conv in self.convs:
            h = torch.relu(conv(e))[:, :, :x.size(1)]
            h = h.masked_fill(~mask, -1e4)                      # ignore padding in the max
            pooled.append(h.max(dim=2).values)
        return self.fc(self.drop(torch.cat(pooled, 1)))

class BiLSTM(nn.Module):
    """Bidirectional LSTM over the token sequence. The text is represented by
    the final hidden states of both directions concatenated with a max-pool
    over all time steps (the max-pool helps on long responses, where the final
    state alone forgets early content)."""
    def __init__(self, vocab_size, n_classes, emb=128, hidden=128, dropout=0.5):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, emb, padding_idx=PAD)
        self.lstm = nn.LSTM(emb, hidden, batch_first=True, bidirectional=True)
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(4 * hidden, n_classes)
    def forward(self, x, lengths):
        e = self.drop(self.emb(x))
        packed = nn.utils.rnn.pack_padded_sequence(e, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out, (h, _) = self.lstm(packed)
        out, _ = nn.utils.rnn.pad_packed_sequence(out, batch_first=True, padding_value=-1e4)
        last = torch.cat([h[0], h[1]], dim=1)                   # forward + backward final states
        mx = out.max(dim=1).values
        return self.fc(self.drop(torch.cat([last, mx], 1)))

# ----------------------------------------------------------------------------- training

def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)

def batches(X, L, y, bs, shuffle):
    idx = torch.randperm(len(y)) if shuffle else torch.arange(len(y))
    for i in range(0, len(y), bs):
        j = idx[i:i + bs]
        m = int(L[j].max())
        yield X[j, :m].to(DEVICE), L[j], y[j].to(DEVICE)

@torch.no_grad()
def predict(model, X, L, bs=64):
    model.eval()
    preds = []
    for xb, lb, _ in batches(X, L, torch.zeros(len(L), dtype=torch.long), bs, False):
        preds.append(model(xb, lb).argmax(1).cpu())
    return torch.cat(preds).numpy()

def train_nn(arch, train, val, labels, mode="output", transform="none", max_out=MAX_OUT,
             seed=0, epochs=15, bs=32, lr=1e-3, patience=4):
    set_seed(seed)
    tr_seq = make_sequences(train, mode, transform, max_out)
    vocab = Vocab(tr_seq)                                       # vocab from TRAIN only
    lab = {l: i for i, l in enumerate(labels)}
    Xtr, Ltr = to_tensor(tr_seq, vocab); ytr = torch.tensor(train["llm"].map(lab).values)
    Xva, Lva = to_tensor(make_sequences(val, mode, transform, max_out), vocab); yva = val["llm"].map(lab).values
    model = (CNN if arch == "cnn" else BiLSTM)(len(vocab), len(labels)).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    lossf = nn.CrossEntropyLoss()
    best, best_state, bad, hist = -1, None, 0, []
    for ep in range(epochs):
        model.train(); tot = 0
        for xb, lb, yb in batches(Xtr, Ltr, ytr, bs, True):
            opt.zero_grad()
            loss = lossf(model(xb, lb), yb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step(); tot += loss.item() * len(yb)
        vf1 = f1_score(yva, predict(model, Xva, Lva), average="macro")
        hist.append(dict(epoch=ep + 1, train_loss=tot / len(ytr), val_macro_f1=vf1))
        if vf1 > best:
            best, bad = vf1, 0
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= patience: break                          # early stopping on val macro-F1
    model.load_state_dict(best_state)
    def evaluate(df):
        X, L = to_tensor(make_sequences(df, mode, transform, max_out), vocab)
        return np.array(labels)[predict(model, X, L)]       # back to label strings
    return evaluate, hist

def tfidf_baseline(train, labels, mode="output", transform="none"):
    """Linear baseline: word 1-2gram + char 2-4gram TF-IDF -> logistic regression."""
    def texts(df):
        t = df["output"].map(TRANSFORMS[transform])
        if mode == "input": return df["input"]
        if mode == "both": return df["input"] + " <sep> " + t
        return t
    vec_w = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=50000, sublinear_tf=True, lowercase=False, token_pattern=r"(?u)\b\w+\b|[^\w\s]")
    vec_c = TfidfVectorizer(analyzer="char", ngram_range=(2, 4), min_df=2, max_features=50000, sublinear_tf=True)
    from scipy.sparse import hstack
    Xtr = hstack([vec_w.fit_transform(texts(train)), vec_c.fit_transform(texts(train))])
    clf = LogisticRegression(max_iter=2000, C=10).fit(Xtr, train["llm"])
    return lambda df: clf.predict(hstack([vec_w.transform(texts(df)), vec_c.transform(texts(df))]))

def metrics(y_true, y_pred, labels):
    return dict(acc=accuracy_score(y_true, y_pred), macro_f1=f1_score(y_true, y_pred, average="macro"),
                cm=confusion_matrix(y_true, y_pred, labels=labels).tolist())

def summarize(runs):
    """runs: list of metric dicts over seeds -> mean/std (+ summed confusion matrix)."""
    out = {}
    for k in ("acc", "macro_f1"):
        v = [r[k] for r in runs]
        out[k] = float(np.mean(v)); out[k + "_std"] = float(np.std(v))
    out["cm"] = np.sum([r["cm"] for r in runs], axis=0).tolist()
    return out

def run_setting(df, labels, seeds, epochs, arches=("cnn", "lstm", "tfidf"), **kw):
    """Train/eval each architecture over seeds on by-prompt splits. Also returns
    per-task accuracy so RQ3 can compare in-domain vs cross-domain."""
    res = {}
    for arch in arches:
        runs, per_task, hists = [], [], []
        for s in seeds:
            tr, va, te = split_by_prompt(df, s)
            if arch == "tfidf":
                ev = tfidf_baseline(tr, labels, kw.get("mode", "output"), kw.get("transform", "none"))
            else:
                ev, h = train_nn(arch, tr, va, labels, seed=s, epochs=epochs, **kw); hists.append(h)
            pred = ev(te)
            runs.append(metrics(te["llm"].values, pred, labels))
            per_task.append({t: accuracy_score(te["llm"][te["task"] == t], pred[(te["task"] == t).values])
                             for t in sorted(te["task"].unique())})
        res[arch] = summarize(runs)
        res[arch]["per_task_acc"] = {t: float(np.mean([p[t] for p in per_task])) for t in per_task[0]}
        if hists: res[arch]["history_seed0"] = hists[0]
        print(f"    {arch:6s} acc={res[arch]['acc']:.3f}±{res[arch]['acc_std']:.3f}  "
              f"macroF1={res[arch]['macro_f1']:.3f}±{res[arch]['macro_f1_std']:.3f}")
    return res

# ----------------------------------------------------------------------------- RQ4 style features

def style_features(text):
    words = re.findall(r"\b\w+\b", text)
    lines = text.split("\n")
    low = [w.lower() for w in words]
    win = low[:200]                                             # TTR on a fixed window so it's not just a length effect
    return dict(
        n_chars=len(text), n_words=len(words),
        avg_word_len=np.mean([len(w) for w in words]) if words else 0,
        ttr_first200=len(set(win)) / len(win) if win else 0,
        n_lines=len(lines), blank_line_frac=sum(1 for l in lines if not l.strip()) / max(1, len(lines)),
        headers=len(re.findall(r"^\s*#{1,6}\s", text, re.M)),
        bullets=len(re.findall(r"^\s*[-*+]\s", text, re.M)),
        numbered=len(re.findall(r"^\s*\d+\.\s", text, re.M)),
        bold=len(re.findall(r"\*\*[^*]+\*\*", text)),
        code_blocks=text.count("```") // 2,
        latex=len(re.findall(r"\\\(|\\\[|\$\$|\\frac|\\boxed", text)),
        emoji=len(re.findall(r"[\U0001F300-\U0001FAFF☀-➿]", text)),
        questions=text.count("?"), exclaims=text.count("!"),
        avg_sent_len=len(words) / max(1, len(re.findall(r"[.!?](\s|$)", text))),
    )

SELF_NAMES = r"\b(?:openai|chatgpt|gpt-?\d|gemini|google|bard|llama|meta ai|deepseek|anthropic|claude|qwen|mistral)\b"

def self_mentions(df):
    """Fraction of each model's outputs that name an LLM/company. If high, the
    classifier could 'cheat' on these tokens; report it, and RQ4 masks them."""
    hit = df["output"].str.lower().str.contains(SELF_NAMES, regex=True)
    return hit.groupby(df["llm"]).mean().round(3).to_dict()

def mask_names(t):
    return re.sub(SELF_NAMES, "<model>", t, flags=re.I)

TRANSFORMS["mask_names"] = mask_names

def top_ngrams(df, k=15):
    """Most indicative word 1-2grams per model (positive LogReg weights on TF-IDF).
    Descriptive only (fit on all data), answers RQ4 'what signals are used?'."""
    vec = TfidfVectorizer(ngram_range=(1, 2), min_df=3, sublinear_tf=True, lowercase=False,
                          token_pattern=r"(?u)\b\w+\b|[^\w\s]")
    X = vec.fit_transform(df["output"])
    clf = LogisticRegression(max_iter=3000, C=10).fit(X, df["llm"])
    vocab = np.array(vec.get_feature_names_out())
    W = clf.coef_ if len(clf.classes_) > 2 else np.vstack([-clf.coef_[0], clf.coef_[0]])
    return {c: [repr(x)[1:-1] for x in vocab[np.argsort(-W[i])[:k]]] for i, c in enumerate(clf.classes_)}

# ----------------------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/responses.jsonl")
    ap.add_argument("--rq", nargs="+", type=int, default=[1, 2])
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--out", default="results")
    ap.add_argument("--archs", nargs="+", default=["cnn", "lstm", "tfidf"], help="subset of: cnn lstm tfidf")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    seeds = list(range(args.seeds))
    archs = tuple(args.archs)

    df = load_data(args.data)
    labels = sorted(df["llm"].unique())
    info = dict(n_samples=len(df), n_prompts=df["prompt_id"].nunique(), labels=labels,
                per_class=df["llm"].value_counts().to_dict(), per_task=df.drop_duplicates("prompt_id")["task"].value_counts().to_dict(),
                truncated_frac=(df["finish_reason"] == "length").groupby(df["llm"]).mean().round(3).to_dict() if "finish_reason" in df else None,
                self_mention_frac=self_mentions(df), device=str(DEVICE))
    print(json.dumps(info, indent=1))
    json.dump(info, open(f"{args.out}/dataset_info.json", "w"), indent=1)
    save = lambda name, obj: json.dump(obj, open(f"{args.out}/{name}.json", "w"), indent=1)

    if 1 in args.rq or 2 in args.rq:
        modes = ["output"] if 2 not in args.rq else ["input", "output", "both"]
        res = {}
        for m in modes:
            print(f"\n== mode: {m}")
            res[m] = run_setting(df, labels, seeds, args.epochs, arches=archs, mode=m)
        save("rq1_rq2", dict(labels=labels, chance=1 / len(labels), results=res))

    if 3 in args.rq:
        # Paired design per held-out task group G (and per seed):
        #   G is split 50/50 into G_test and G_pool; the other groups into O_train / O_val.
        #   "unseen": train on n_train prompts from O_train only (never sees G)
        #   "seen":   train on all of G_pool + (n_train - |G_pool|) prompts from O_train
        #   Both use the same val set (O_val) and are tested on the SAME G_test.
        # Same training size and same test prompts -> the gap isolates the effect
        # of having seen the task. The largest group is not held out: holding it
        # out would leave too little training data (it would confound task shift
        # with training-set size).
        sizes = df.drop_duplicates("prompt_id")["task"].value_counts()
        held_groups = [g for g in sizes.index if g != sizes.idxmax()]
        n_train = int(0.85 * (sizes.sum() - max(sizes[g] for g in held_groups))) - 1
        print(f"\n== RQ3: held-out groups {held_groups}; training size fixed at {n_train} prompts")
        res = {}
        for held in held_groups:
            res[held] = {}
            for arch in archs:
                seen_runs, unseen_runs = [], []
                for s in seeds:
                    rng = np.random.RandomState(s)
                    G = df[df["task"] == held]; O = df[df["task"] != held]
                    gp = G["prompt_id"].unique(); rng.shuffle(gp)
                    g_test, g_pool = gp[:len(gp) // 2], gp[len(gp) // 2:]
                    o_tr, o_va = split_train_val(O, s)
                    o_ids = o_tr["prompt_id"].unique(); rng.shuffle(o_ids)
                    pick = lambda ids: df[df["prompt_id"].isin(ids)].reset_index(drop=True)
                    unseen_tr = pick(o_ids[:n_train])
                    seen_tr = pick(np.concatenate([g_pool, o_ids[:n_train - len(g_pool)]]))
                    test = pick(g_test)
                    for tr, runs in ((unseen_tr, unseen_runs), (seen_tr, seen_runs)):
                        ev = tfidf_baseline(tr, labels) if arch == "tfidf" else train_nn(arch, tr, o_va, labels, seed=s, epochs=args.epochs)[0]
                        runs.append(metrics(test["llm"].values, ev(test), labels))
                res[held][arch] = dict(seen=summarize(seen_runs), unseen=summarize(unseen_runs),
                                       n_train_prompts=n_train, n_test_prompts=len(g_test))
                print(f"    {held:10s} {arch:6s} seen={res[held][arch]['seen']['acc']:.3f}  unseen={res[held][arch]['unseen']['acc']:.3f}"
                      f"  (test prompts={len(g_test)})")
        save("rq3", dict(labels=labels, chance=1 / len(labels), results=res))

    if 4 in args.rq:
        # (a) descriptive statistics per model
        feats = pd.DataFrame([style_features(t) for t in df["output"]])
        feats["llm"], feats["task"] = df["llm"].values, df["task"].values
        stats = feats.groupby("llm").mean(numeric_only=True).round(3)
        stats_task = feats.groupby(["task", "llm"]).mean(numeric_only=True).round(2)
        print("\n== RQ4 style statistics (mean per model)\n", stats.T.to_string())
        stats.to_csv(f"{args.out}/rq4_style_stats.csv"); stats_task.to_csv(f"{args.out}/rq4_style_stats_by_task.csv")
        # (b) how far do style features alone get? (logistic regression, same splits)
        fcols = [c for c in feats.columns if c not in ("llm", "task")]
        runs, coefs = [], []
        for s in seeds:
            tr, _, te = split_by_prompt(df, s)
            Xtr = feats.loc[df["prompt_id"].isin(tr["prompt_id"]), fcols]; ytr = feats.loc[Xtr.index, "llm"]
            Xte = feats.loc[df["prompt_id"].isin(te["prompt_id"]), fcols]; yte = feats.loc[Xte.index, "llm"]
            sc = StandardScaler().fit(Xtr)
            clf = LogisticRegression(max_iter=3000).fit(sc.transform(Xtr), ytr)
            runs.append(metrics(yte.values, clf.predict(sc.transform(Xte)), labels)); coefs.append(clf.coef_)
        feat_only = summarize(runs)
        coef = pd.DataFrame(np.mean(coefs, 0), index=clf.classes_, columns=fcols).round(2)
        coef.to_csv(f"{args.out}/rq4_feature_coefs.csv")
        print(f"\n    style-features-only LogReg acc={feat_only['acc']:.3f}±{feat_only['acc_std']:.3f}")
        top = top_ngrams(df)
        print("\n== RQ4 most indicative n-grams per model")
        for c, ws in top.items(): print(f"    {c:10s}", " | ".join(ws))
        # (c) ablations: remove a signal, retrain, measure the drop
        ablations = {
            "full": dict(transform="none", max_out=MAX_OUT),
            "mask_model_names": dict(transform="mask_names", max_out=MAX_OUT),  # self-identification removed
            "no_format": dict(transform="no_format", max_out=MAX_OUT),         # markdown + line breaks removed
            "lower_no_punct": dict(transform="lower_no_punct", max_out=MAX_OUT),  # only lowercased words remain
            "first_50_tokens": dict(transform="none", max_out=50),              # removes most length/structure info
        }
        abl = {}
        for name, kw in ablations.items():
            print(f"\n== RQ4 ablation: {name}")
            abl[name] = run_setting(df, labels, seeds, args.epochs, arches=tuple(a for a in archs if a != "tfidf"), mode="output", **kw)
        save("rq4", dict(labels=labels, feature_only=feat_only, top_ngrams=top, ablations=abl, style_stats=stats.to_dict()))

    print(f"\nresults written to {args.out}/ ; run `python report_figs.py` for figures/tables")

if __name__ == "__main__":
    t = time.time(); main(); print(f"total time {time.time() - t:.0f}s")
