## RQ1/RQ2: accuracy and macro-F1 (mean ± std over seeds, test = unseen prompts)

Chance = 0.250

| Input | Model | Accuracy | Macro-F1 |
|---|---|---|---|
| input | CNN | 0.250 ± 0.000 | 0.193 ± 0.022 |
| input | BiLSTM | 0.250 ± 0.000 | 0.216 ± 0.006 |
| input | TF-IDF + LogReg | 0.250 ± 0.000 | 0.100 ± 0.000 |
| output | CNN | 0.815 ± 0.024 | 0.816 ± 0.025 |
| output | BiLSTM | 0.771 ± 0.004 | 0.768 ± 0.004 |
| output | TF-IDF + LogReg | 0.824 ± 0.011 | 0.822 ± 0.012 |
| both | CNN | 0.829 ± 0.020 | 0.828 ± 0.021 |
| both | BiLSTM | 0.736 ± 0.023 | 0.734 ± 0.022 |
| both | TF-IDF + LogReg | 0.809 ± 0.011 | 0.808 ± 0.011 |

### Per-task test accuracy (output only)

| Model | general_qa | technical | writing |
|---|---|---|---|
| CNN | 0.841 | 0.763 | 0.732 |
| BiLSTM | 0.791 | 0.821 | 0.645 |
| TF-IDF + LogReg | 0.838 | 0.814 | 0.763 |

## RQ3: does the classifier work on a task type it never saw?

Same training size (573 prompts) in both conditions; both tested on the same held-out prompts of the task.

| Held-out task | Model | Seen task | Unseen task | Drop |
|---|---|---|---|---|
| writing (n=64) | CNN | 0.721 ± 0.021 | 0.708 ± 0.023 | +0.013 |
| technical (n=42) | CNN | 0.744 ± 0.010 | 0.710 ± 0.038 | +0.034 |
| writing (n=64) | BiLSTM | 0.641 ± 0.011 | 0.645 ± 0.025 | -0.004 |
| technical (n=42) | BiLSTM | 0.772 ± 0.023 | 0.732 ± 0.013 | +0.040 |
| writing (n=64) | TF-IDF + LogReg | 0.763 ± 0.029 | 0.710 ± 0.021 | +0.053 |
| technical (n=42) | TF-IDF + LogReg | 0.778 ± 0.027 | 0.740 ± 0.028 | +0.038 |

### RQ3 per-model recall, seen → unseen (CNN / BiLSTM)

| Held-out task | claude | gemini | gpt | llama |
|---|---|---|---|---|
| writing | 0.77→0.86 / 0.89→0.88 | 0.84→0.74 / 0.72→0.71 | 0.56→0.53 / 0.37→0.40 | 0.71→0.70 / 0.58→0.59 |
| technical | 0.89→0.89 / 0.95→0.91 | 0.70→0.64 / 0.79→0.79 | 0.76→0.74 / 0.65→0.70 | 0.63→0.57 / 0.69→0.53 |

## RQ4: signal-removal ablations (output only)

| Variant | CNN acc | BiLSTM acc |
|---|---|---|
| full | 0.816 ± 0.022 | 0.771 ± 0.004 |
| mask_model_names | 0.806 ± 0.021 | 0.776 ± 0.027 |
| no_format | 0.687 ± 0.015 | 0.623 ± 0.027 |
| lower_no_punct | 0.598 ± 0.042 | 0.605 ± 0.016 |
| first_50_tokens | 0.770 ± 0.016 | 0.744 ± 0.022 |

### Most indicative n-grams per model (TF-IDF + LogReg weights)

- **claude**: `Here '`, `: 1`, `'`, `:`, `' s`, `s`, `s a`, `Here`, `: -`, `this`, `for`, `It '`, `2 .`, `6`, `1 .`
- **gemini**: `: *`, `. -`, `*`, `It is`, `* -`, `it is`, `* The`, `* *`, `* This`, `. They`, `that is`, `you are`, `is important`, `Alps`, `They`
- **gpt**: `# #`, `’`, `Sure`, `* :`, `- *`, `’ s`, `#`, `* *`, `. -`, `* -`, `. *`, `Sure ,`, `Sure !`, `! Here`, `: -`
- **llama**: `*`, `* :`, `Here is`, `* 1`, `* *`, `Here`, `) *`, `!`, `. *`, `, such`, `= =`, `, with`, `(`, `, and`, `I`

Style-features-only logistic regression: acc = 0.573 ± 0.023

### Mean style statistics per model

| Feature | claude | gemini | gpt | llama |
|---|---|---|---|---|
| n_chars | 1489.31 | 1458.15 | 1872.31 | 2044.73 |
| n_words | 230.33 | 226.30 | 282.98 | 324.41 |
| avg_word_len | 4.94 | 4.93 | 4.94 | 4.79 |
| ttr_first200 | 0.64 | 0.62 | 0.63 | 0.59 |
| n_lines | 28.01 | 21.97 | 28.49 | 27.57 |
| blank_line_frac | 0.33 | 0.26 | 0.26 | 0.28 |
| headers | 0.13 | 0.11 | 1.66 | 0.23 |
| bullets | 3.56 | 6.10 | 6.58 | 3.94 |
| numbered | 7.33 | 3.58 | 5.08 | 5.87 |
| bold | 0.01 | 4.24 | 7.54 | 7.50 |
| code_blocks | 0.15 | 0.13 | 0.20 | 0.18 |
| latex | 0.00 | 0.03 | 0.58 | 0.02 |
| emoji | 0.17 | 0.06 | 0.17 | 0.02 |
| questions | 0.43 | 0.36 | 0.50 | 0.65 |
| exclaims | 0.44 | 0.15 | 0.67 | 0.77 |
| avg_sent_len | 17.35 | 20.90 | 17.27 | 21.91 |
