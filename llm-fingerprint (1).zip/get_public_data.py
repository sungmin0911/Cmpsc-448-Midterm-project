"""Builds data/responses.jsonl from a PUBLIC dataset instead of calling APIs.

Source: AlpacaEval (Li et al., 2023; github.com/tatsu-lab/alpaca_eval).
  - 805 fixed instructions; the repo publishes each model's answer to all 805
    in results/<model>/model_outputs.json.
  - Data license: CC BY-NC 4.0

Run:  python get_public_data.py      (needs internet access to GitHub)
"""
import json, os, re, urllib.request

REPO = "https://raw.githubusercontent.com/tatsu-lab/alpaca_eval/main/results/{}/model_outputs.json"
MODELS = {  # label: (family, AlpacaEval folder name)
    "gpt":      ("GPT (OpenAI)",       "gpt-4o-2024-05-13"),
    "claude":   ("Claude (Anthropic)", "claude-3-5-sonnet-20240620"),
    "llama":    ("Llama (Meta)",       "Meta-Llama-3.1-70B-Instruct-Turbo"),
    "gemini":   ("Gemini (Google)",    "gemini-pro"),
    # "qwen":     ("Qwen (Alibaba)",     "Qwen2-72B-Instruct"),
    # "mistral":  ("Mistral",            "mistral-large-2402"),
    # "deepseek": ("DeepSeek",           "deepseek-llm-67b-chat"),
}

# AlpacaEval has no task labels, so we assign one with transparent keyword rules
# (order matters: first match wins). Used for RQ3. Spot-check some by hand and
# report that the labels are heuristic. Coding and math are merged into
# "technical" because math alone has only ~38 instructions.
TASK_RULES = [
    ("technical", r"\b(code|python|javascript|java|c\+\+|function|sql|program|script|html|css|regex|algorithm|bug|compile)\b"),
    # math: explicit math words only. Digit patterns ("70-75 dB", "9-11 am") and
    # "how many"/"solve" (trivia, crosswords) were checked by hand and mislabel too much.
    ("technical", r"\b(calculate|equation|math|mathematical|probability|integral|derivative|sum of|f\(x\))"),
    ("writing", r"\b(write|poem|story|essay|letter|email|slogan|tweet|song|lyrics|haiku|blog|rewrite|paraphrase|caption)\b"),
]

def task_of(text):
    t = text.lower()
    for name, pat in TASK_RULES:
        if re.search(pat, t):
            return name
    return "general_qa"

def fetch(folder):
    with urllib.request.urlopen(REPO.format(folder), timeout=60) as r:
        return json.load(r)

if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    data = {}
    for llm, (family, folder) in MODELS.items():
        rows = fetch(folder)
        # match by instruction TEXT, not position (some files are in a different order)
        data[llm] = {r["instruction"]: r for r in rows}
        print(f"{llm:9s} {folder:36s} {len(rows)} rows")
    common = sorted(set.intersection(*(set(d) for d in data.values())))
    ids = {instr: i for i, instr in enumerate(common)}
    n = 0
    with open("data/responses.jsonl", "w", encoding="utf-8") as f:
        for llm, (family, folder) in MODELS.items():
            for instr in common:
                r = data[llm][instr]
                rec = dict(llm=llm, family=family, model_id=folder, prompt_id=ids[instr],
                           task=task_of(instr), source=r.get("dataset"), input=instr,
                           output=(r.get("output") or "").strip(), finish_reason="unknown")
                f.write(json.dumps(rec, ensure_ascii=False) + "\n"); n += 1
    print(f"\n{len(common)} shared instructions x {len(MODELS)} models = {n} rows -> data/responses.jsonl")
    from collections import Counter
    print("task labels (per instruction):", dict(Counter(task_of(i) for i in common)))
