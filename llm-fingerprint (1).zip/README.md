# Who Wrote It? Identifying LLMs from Their Responses

CMPSC 448 midterm project. Sungmin Song (individual project; team leader).

## Pipeline

| Step | Command | Output |
|---|---|---|
| 1. Get data | `python get_public_data.py` | `data/responses.jsonl` (805 instructions × 4 LLMs = 3,220 rows) |
| 2. Train + evaluate | `python train.py --rq 1 2 3 4` | `results/*.json`, `results/*.csv` |
| 3. Figures/tables | `python report_figs.py` | `results/figs/*.png`, `results/tables.md` |

Everything runs in `llm_fingerprint.ipynb` on Google Colab (GPU runtime).
Requirements: `torch pandas numpy scikit-learn matplotlib` (all preinstalled on Colab).

## Dataset

- **Source:** AlpacaEval (Li et al., 2023, https://github.com/tatsu-lab/alpaca_eval). The repository publishes each model's answers to the same fixed set of 805 instructions. The instructions come from five public collections: self-instruct, OpenAssistant, Koala, Anthropic helpful-base and Vicuna. The data is licensed CC BY-NC 4.0, so it can be used for a non-commercial class project with attribution.
- **Models (4 families, one model each):** GPT-4o (`gpt-4o-2024-05-13`), Claude 3.5 Sonnet (`claude-3-5-sonnet-20240620`), Llama 3.1 70B Instruct (`Meta-Llama-3.1-70B-Instruct-Turbo`), Gemini Pro (`gemini-pro`).
- **Record format:** `(LLM_name, LLM_input, LLM_output)`, plus `prompt_id`, `task` and `source`.
- **Balance:** every model answered every instruction, so the classes are exactly balanced. Rows are matched across models by instruction text, not file order (one file is in a different order). Prompts with an empty answer from any model are dropped for all models.
- **Generation settings:** these were chosen by the AlpacaEval contributors, not by us. Gemini Pro is also an older model (late 2023) than the others (mid-2024). Both are limitations.
- **Task labels (for RQ3):** AlpacaEval has no task labels, so we assign them with keyword rules in `get_public_data.py`: technical (coding + math, 84), writing (128) and general QA (593). We checked the rules by hand and dropped two that mislabeled often. The labels are still heuristic and somewhat noisy.
- **Quality checks:** `results/dataset_info.json` records class counts and how often each model names a model or company in its answer (self-identification).

## Experimental design

- **Split by prompt (70/15/15).** All responses to a given prompt land in the same split, so test prompts are never seen during training. The split is stratified by task.
- **Tokenizer:** keeps case, punctuation and newlines as tokens, since formatting may be part of the fingerprint. The vocabulary is built from the training data only.
- **CNN:** embedding 128 → Conv1d with filter widths {3,4,5} × 128 filters → ReLU → masked max-over-time pooling → dropout 0.5 → linear.
- **BiLSTM:** embedding 128 → bidirectional LSTM (128 per direction, packed sequences) → [final forward state ‖ final backward state ‖ max-pool over time] → dropout 0.5 → linear.
- **Training:** Adam (lr 1e-3), batch 32, cross-entropy, gradient clipping at 5, up to 15 epochs, early stopping on validation macro-F1 (patience 4). Outputs are truncated to 600 tokens and inputs to 64.
- **Baseline:** TF-IDF (word 1–2-grams + character 2–4-grams) with logistic regression.
- **Reporting:** every number is the mean ± std over 3 seeds; each seed uses a different split and initialization.

| RQ | Setup |
|---|---|
| RQ1 | Output only → which LLM |
| RQ2 | Input only vs output only vs input + output (`input <sep> output`) |
| RQ3 | Paired, size-matched test for each smaller task group G (technical, writing). G is split in half. *Unseen*: train only on other groups. *Seen*: train on half of G plus other groups. Both use the same number of training prompts and are tested on the same other half of G, so the gap measures only the effect of having seen the task. General QA is not held out, because removing it would leave too little training data. Per-model recall answers "which models generalize". |
| RQ4 | Per-model style statistics, the most indicative n-grams per model, a classifier on 16 style features alone, and ablations that retrain after masking model/company names, removing formatting, removing punctuation/case, or keeping only the first 50 tokens. |
